/*
 * @Author: Ouber23
 * @Date: 2018-07-10 11:37:54
 * @Last Modified by: Ouber23
 * @Last Modified time: 2018-07-10 00:55:19
 */

<template>
    <div>
        <h1>历史Log模块</h1>
    </div>
</template>
<script>
export default {
  name: 'EnergyMonitor',
  data () {
    return {

    }
  }
}
</script>
